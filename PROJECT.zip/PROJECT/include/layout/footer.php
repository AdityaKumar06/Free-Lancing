<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>- Your Trusted Global Partner in Electronics & Industrial Trade</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <!-- Company Logo and Tagline Section -->
        <div class="container text-center mb-5">
            <div class="d-flex justify-content-center align-items-center">
                <img src="img/logo-white.png" alt="Encore Global Logo" style="height: 50px;" class="me-3">
                <div class="text-start">
                    <h4 class="text-white mb-0">Encore Global</h4>
                    <small class="text-white">From vision to Victory</small>
                </div>
            </div>
        </div>
        
        <div class="container py-3">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Address</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+86 1314 580 2785</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>contact@encoreg.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Opening Hours</h4>
                    <h6 class="text-light">Monday - Friday:</h6>
                    <p class="mb-4">09.00 AM - 09.00 PM</p>
                    <h6 class="text-light">Saturday - Sunday:</h6>
                    <p class="mb-0">09.00 AM - 12.00 PM</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Our Services</h4>
                    <a class="btn btn-link" href="">Industrial Solutions</a>
                    <a class="btn btn-link" href="">Connectors for Automotive</a>
                    <a class="btn btn-link" href="">Electronics Component</a>
                    <a class="btn btn-link" href="">Renewable Energy</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div>
                        <h4 class="text-light mb-4">Quick Links</h4> 
                        <a class="btn btn-link" href="<?= HTTP_SERVER ?>about">About Us</a>
                        <a class="btn btn-link" href="<?= HTTP_SERVER ?>service">Our Services</a>
                        <!-- <a class="btn btn-link" href="">Quality Policy</a> -->
                        <a class="btn btn-link" href="<?= HTTP_SERVER ?>contact">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="<?= HTTP_SERVER ?>index.php">Encore Global Co.Limited</a>.  All Rights Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-links">
                            <a class="text-light" href="">Privacy Policy</a>
                            <span class="text-muted mx-2">|</span>
                            <a class="text-light" href="">Terms & Conditions</a>
                            <span class="text-muted mx-2">|</span>
                            <a class="text-light" href="">Sitemap</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>

</body>

</html>