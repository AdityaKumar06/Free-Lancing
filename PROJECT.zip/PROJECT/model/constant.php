<?php
if (!defined('HTTP_SERVER')) {
    define('HTTP_SERVER', 'http://localhost/PROJECT/');
}




// FOR LIVE JUST UNCOMMENT

// <?php
// if (!defined('HTTP_SERVER')) {
//     // Use dynamic base URL based on server
//     $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
//     $domain = $_SERVER['HTTP_HOST'];
//     $base = '/'; // No subfolder

//     define('HTTP_SERVER', $protocol . $domain . $base);
// }
// ?>
