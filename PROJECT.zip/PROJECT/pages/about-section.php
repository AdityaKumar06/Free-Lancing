<?php
include('../model/constant.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>About Us | Your Trusted Global Partner in Electronics & Industrial Trade</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="Learn more about our company's history, mission, and values" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= HTTP_SERVER ?>lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?= HTTP_SERVER ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= HTTP_SERVER ?>css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= HTTP_SERVER ?>css/style.css" rel="stylesheet">

    <!-- Custom About Page Styles -->
    <style>
        .about-hero {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('<?= HTTP_SERVER ?>img/about-hero.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 60px 0;
            margin-bottom: 30px;
        }

        .feature-icon {
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(13, 110, 253, 0.1);
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .stats-section {
            background-color: #f8f9fa;
            padding: 60px 0;
        }

        .stat-item {
            text-align: center;
            padding: 20px;
        }

        .stat-number {
            font-size: 48px;
            font-weight: 700;
            color: #0d6efd;
        }
    </style>
</head>

<body>

    <?php include '../include/layout/header.php' ?>
    <?php include '../spinner.php'; ?>
    <?php include '../include/layout/navbar.php' ?>
    <div class="container-fluid page-header page-header-about  py-5 mb-5">
        <div class="container py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a class="text-white" href="<?= HTTP_SERVER ?>index">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Services</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Compact Hero Section -->

    <!-- About Section -->
    <div class="container-xxl py-5" id="our-story">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="position-relative overflow-hidden rounded pe-5" style="height: 400px;">
                        <img class="img-fluid w-100 h-100" src="<?= HTTP_SERVER ?>img/main image.jpg" style="object-fit: cover;" alt="Encore Global">
                        <div class="position-absolute top-0 end-0 bg-white p-2" style="width: 150px; height: 195px; transform: rotate(0deg);">
                            <img src="<?= HTTP_SERVER ?>img/all-type-250x250.webp" class="img-fluid rounded" alt="Our Office">
                            <div class="bg-primary text-white text-center p-1 rounded mt-1">
                                <h5 class="mb-0">Trusted</h5>
                                <small class="mb-0">Since 2022</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <h6 class="text-primary text-uppercase mb-2">About Us</h6>
                    <h2 class="mb-4">We Are Your Trusted Partner for Global Sourcing and Industrial Solutions</h2>
                    <p class="mb-4" style="text-align: justify;">Established in 2022 and headquartered in Hong Kong, Encore Global Co., Limited is a dynamic company specializing in high-quality electronic components and industrial solutions. With a global network and a customer-centric approach, we serve industries such as electronics, automotive, manufacturing, and renewable energy. We are committed to providing value-driven solutions to enhance innovation and efficiency worldwide.</p>
                    <div class="row g-2 mb-4">
                        <div class="col-sm-6">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-2">
                                    <i class="fa fa-check text-white"></i>
                                </div>
                                <h6 class="mb-0">Global Sourcing Expertise</h6>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-2">
                                    <i class="fa fa-check text-white"></i>
                                </div>
                                <h6 class="mb-0">Quality Assurance</h6>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-2">
                                    <i class="fa fa-check text-white"></i>
                                </div>
                                <h6 class="mb-0">Customer-Focused Solutions</h6>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-2">
                                    <i class="fa fa-check text-white"></i>
                                </div>
                                <h6 class="mb-0">Sustainability Commitment</h6>
                            </div>
                        </div>
                    </div>
                    <div class="bg-light p-3 rounded">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0 rounded-circle bg-primary p-2">
                                <i class="fa fa-phone-alt fa-lg text-white"></i>
                            </div>
                            <div class="ms-3">
                                <h5 class="mb-1">Need Any Help?</h5>
                                <p class="mb-0 text-primary fw-bold">+86 1314 580 2785</p>
                                <p class="mb-0 text-primary fw-bold">+91 9579 90 1473</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Stats Section -->
    <div class="stats-section">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number" data-count="250">0</div>
                        <h5>Happy Clients</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number" data-count="500">0</div>
                        <h5>Projects Completed</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number" data-count="50">0</div>
                        <h5>Team Members</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item">
                        <div class="stat-number" data-count="10">0</div>
                        <h5>Awards Won</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mission & Vision -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto" style="max-width: 800px;">
                <h6 class="text-primary text-uppercase">Our Values</h6>
                <h2 class="mb-5">What Drives Us Forward</h2>
            </div>
            <div class="row g-4">
                <!-- Mission Section -->
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="bg-light p-4 h-100 rounded">
                        <div class="feature-icon mx-auto">
                            <i class="fa fa-bullseye fa-2x text-primary"></i>
                        </div>
                        <h4 class="text-center mb-3">Our Mission</h4>
                        <p class="text-center">To provide innovative electronic components and industrial solutions that exceed client expectations, with a commitment to quality and integrity.</p>
                    </div>
                </div>
                <!-- Vision Section -->
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="bg-primary p-4 h-100 rounded text-white">
                        <div class="feature-icon mx-auto">
                            <i class="fa fa-eye fa-2x text-white"></i>
                        </div>
                        <h4 class="text-center mb-3 text-white">Our Vision</h4>
                        <p class="text-center">To be a globally recognized leader in electronic components and industrial solutions, known for innovation, excellence, and customer satisfaction.</p>
                    </div>
                </div>
                <!-- Values Section -->
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="bg-light p-4 h-100 rounded">
                        <div class="feature-icon mx-auto">
                            <i class="fa fa-handshake fa-2x text-primary"></i>
                        </div>
                        <h4 class="text-center mb-3">Our Core Values</h4>
                        <p class="text-center">Integrity, innovation, collaboration, and customer focus guide us in delivering value-driven solutions and fostering long-term partnerships.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Our History -->


    <!-- CTA Section -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>

    <?php include '../include/layout/footer.php' ?>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/wow/wow.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/easing/easing.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/waypoints/waypoints.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/counterup/counterup.min.js"></script>
    <script src="<?= HTTP_SERVER ?>lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= HTTP_SERVER ?>js/main.js"></script>

    <!-- Custom About Page JS -->
    <script>
        // Animate stats counter
        $(document).ready(function() {
            $('.stat-number').each(function() {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).data('count')
                }, {
                    duration: 2000,
                    easing: 'swing',
                    step: function(now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });
        });
    </script>

</body>

</html>