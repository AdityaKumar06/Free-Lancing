<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Your Trusted Global Partner in Electronics & Industrial Trade</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        .feature-card {
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            background-color: #f0f8ff;
        }

        .icon-box {
            width: 60px;
            height: 60px;
            background: #e6f0ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }

        .feature-card:hover .icon-box {
            background: #d0e4ff;
        }
        .feature-card::before {
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle at center, rgba(0, 119, 255, 0.1), transparent 70%);
    top: 0;
    left: 0;
    z-index: 0;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.feature-card:hover::before {
    opacity: 1;
}


        .service-carousel .bg-light {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
            min-height: 550px;
            /* Adjust based on your content */
        }

        .vision-mission-card .icon-box-sm i {
            font-size: 3rem;
            /* You can adjust this size as needed */
        }
        .divider {
        background: linear-gradient(90deg, rgba(13,110,253,1) 0%, rgba(13,202,240,1) 100%);
    }
    </style>
</head>

<body>


    <!-- Why Choose Us Start -->
    <div class="container py-5">
    <div class="text-center mb-5">
        <h6 class="text-secondary text-uppercase wow fadeInDown" data-wow-delay="0.1s">Why Choose Us?</h6>
        <h1 class="display-5 wow fadeInUp mb-4" data-wow-delay="0.2s">What Sets Encore Global Apart</h1>
        <!-- Added paragraph with gap after heading -->
        <p class="lead text-muted wow fadeInUp" data-wow-delay="0.3s">Encore Global provides end-to-end solutions that ensure the highest quality, performance, and customer satisfaction. Our commitment to excellence drives us to continually improve and adapt to the evolving needs of our clients.</p>
    </div>
    <div class="row g-4">
        
        <!-- Reusable card -->
        <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.1s">
            <div class="feature-card bg-lights rounded h-100 p-4 text-center">
                <div class="icon-box mx-auto mb-3">
                    <i class="fas fa-globe-americas fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold">Global Sourcing Expertise</h5>
                <p class="mb-0">Leveraging a worldwide network to ensure access to the best components and solutions.</p>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.2s">
            <div class="feature-card bg-lights rounded h-100 p-4 text-center">
                <div class="icon-box mx-auto mb-3">
                    <i class="fas fa-shield-alt fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold">Quality Assurance</h5>
                <p class="mb-0">Stringent inspection and supplier vetting for consistent product reliability.</p>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
            <div class="feature-card bg-lights rounded h-100 p-4 text-center">
                <div class="icon-box mx-auto mb-3">
                    <i class="fas fa-user-check fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold">Customer Focus</h5>
                <p class="mb-0">Tailored solutions and responsive support to meet diverse business needs.</p>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.4s">
            <div class="feature-card bg-lights rounded h-100 p-4 text-center">
                <div class="icon-box mx-auto mb-3">
                    <i class="fas fa-leaf fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold">Sustainability Commitment</h5>
                <p class="mb-0">Actively supporting green energy projects with advanced battery technologies.</p>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.5s">
            <div class="feature-card bg-lights rounded h-100 p-4 text-center">
                <div class="icon-box mx-auto mb-3">
                    <i class="fas fa-map-marker-alt fa-2x text-primary"></i>
                </div>
                <h5 class="fw-bold">Strategic Location</h5>
                <p class="mb-0">Based in Hong Kong and Shenzhen, we operate at the heart of Asia’s trade hub with global connectivity.</p>
            </div>
        </div>
    </div>
</div>

    <!-- Why Choose Us End -->



    <div class="container-fluid py-5 px-4 px-lg-0">
        <div class="row g-0">
            <div class="col-lg-3 d-none d-lg-flex">
                <div class="d-flex align-items-center justify-content-center bg-primary w-100 h-100">
                    <h1 class="display-3 text-white m-0" style="transform: rotate(-90deg);">Trusted since 2022</h1>
                </div>
            </div>
            <div class="col-md-12 col-lg-9">
                <div class="ms-lg-5 ps-lg-5">
                    <div class="text-center text-lg-start wow fadeInUp" data-wow-delay="0.1s">
                        <h6 class="text-secondary text-uppercase">Our Services</h6>
                        <h1 class="mb-5">Explore Our Services</h1>
                    </div>
                    <div class="owl-carousel service-carousel position-relative wow fadeInUp" data-wow-delay="0.1s">

                        <!-- Electronics Component -->
                        <div class="bg-light p-4">
                            <div class="d-flex align-items-center justify-content-center border border-5 border-white mb-4" style="width: 75px; height: 75px;">
                                <i class="fa fa-microchip fa-2x text-primary"></i>
                            </div>
                            <h4 class="mb-3">Electronic Components</h4>
                            <p>We specialize in sourcing semiconductors, ICs, transistors, diodes, sensors, and more — delivering quality and efficiency globally.</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Global Sourcing</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Quality Assurance</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Reliable Delivery</p>
                            <a href="<?= HTTP_SERVER ?>pages/service-section.php" class="btn bg-white text-primary w-100 mt-2">Read More<i class="fa fa-arrow-right text-secondary ms-2"></i></a>
                        </div>

                        <!-- Industrial Solutions -->
                        <div class="bg-light p-4">
                            <div class="d-flex align-items-center justify-content-center border border-5 border-white mb-4" style="width: 75px; height: 75px;">
                                <i class="fa fa-industry fa-2x text-primary"></i>
                            </div>
                            <h4 class="mb-3">Industrial Solutions</h4>
                            <p>Providing high-performance industrial equipment and components to enhance automation, efficiency, and manufacturing productivity.</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Advanced Technology</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Customized Solutions</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>End-to-End Support</p>
                            <a href="<?= HTTP_SERVER ?>pages/service-section.php" class="btn bg-white text-primary w-100 mt-2">Read More<i class="fa fa-arrow-right text-secondary ms-2"></i></a>
                        </div>

                        <!-- Automotive Connectors -->
                        <div class="bg-light p-4">
                            <div class="d-flex align-items-center justify-content-center border border-5 border-white mb-4" style="width: 75px; height: 75px;">
                                <i class="fa fa-car fa-2x text-primary"></i>
                            </div>
                            <h4 class="mb-3">Automotive Connectors</h4>
                            <p>High-performance connectors and terminals that ensure superior durability, reliability, and compliance with automotive standards.</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Automotive Grade</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Rigorously Tested</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Custom Configurations</p>
                            <a href="<?= HTTP_SERVER ?>pages/service-section.php" class="btn bg-white text-primary w-100 mt-2">Read More<i class="fa fa-arrow-right text-secondary ms-2"></i></a>
                        </div>

                        <!-- Renewable Energy -->
                        <div class="bg-light p-4">
                            <div class="d-flex align-items-center justify-content-center border border-5 border-white mb-4" style="width: 75px; height: 75px;">
                                <i class="fa fa-solar-panel fa-2x text-primary"></i>
                            </div>
                            <h4 class="mb-3">Renewable Energy</h4>
                            <p>Offering battery cells and storage solutions to support solar, wind, and hybrid energy systems across the globe.</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Sustainable Solutions</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Energy Storage Experts</p>
                            <p class="text-primary fw-medium"><i class="fa fa-check text-success me-2"></i>Eco-Conscious Designs</p>
                            <a href="<?= HTTP_SERVER ?>pages/service-section.php" class="btn bg-white text-primary w-100 mt-2">Read More<i class="fa fa-arrow-right text-secondary ms-2"></i></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service End -->


    <!-- Booking Start -->
    <!-- Solutions Spotlight Start -->
    <div class="container-fluid solutions-spotlight py-5 my-5" style="background: linear-gradient(#1E60AA, rgba(58, 123, 213, 0.9)), url('<?= HTTP_SERVER ?>img/solutions-bg.jpg'); background-size: cover; background-position: center;">
        <div class="container py-5">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="text-white text-uppercase mb-3">Our Solutions</h6>
                    <h1 class="display-5 text-white mb-4">Renewable Energy & Industrial Solutions</h1>
                    <p class="text-white mb-4">Encore Global delivers high-quality components supporting renewable energy and industrial systems worldwide. We are driving sustainability and efficiency through reliable and forward-thinking technology.</p>
                    <div class="d-flex mb-4">
                        <div class="flex-shrink-0 bg-white rounded-circle p-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-solar-panel text-primary fa-2x"></i>
                        </div>
                        <div class="ms-4">
                            <h5 class="text-white">Renewable Energy</h5>
                            <p class="text-white mb-0">Battery cells and storage components for solar, wind, and hybrid systems</p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="flex-shrink-0 bg-white rounded-circle p-3" style="width: 60px; height: 60px;">
                            <i class="fas fa-industry text-primary fa-2x"></i>
                        </div>
                        <div class="ms-4">
                            <h5 class="text-white">Industrial Solutions</h5>
                            <p class="text-white mb-0">Advanced equipment and components for automation and manufacturing</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="bg-white rounded p-4 p-sm-5">
                        <div class="row g-3">
                            <div class="col-12 text-center">
                                <h3 class="mb-3">Key Differentiators</h3>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>Industrial Grade Quality</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>High-Performance Reliability</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>Just-in-Time Manufacturing</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>End-to-End Traceability</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>Reliable Component Sourcing</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center bg-light rounded p-3 h-100">
                                    <i class="fas fa-check-circle text-primary me-3 fs-4"></i>
                                    <span>Custom Industrial Solutions</span>
                                </div>
                            </div>
                            <div class="col-12 text-center pt-4">
                                <a href="<?= HTTP_SERVER ?>contact" class="btn btn-primary py-3 px-5">Get a Custom Solution</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- Mission & Vision Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                <h6 class="text-secondary text-uppercase">Our Commitment</h6>
                <h1 class="display-5 mb-4">Vision & Mission</h1>
                <p class="mb-4 fs-5  text-dark">Guiding principles that drive our business forward and define our relationship with clients worldwide</p>
                <div class="divider mx-auto bg-primary" style="width: 80px; height: 4px;"></div>
            </div>

            <div class="row g-4">
                <!-- Vision Card -->
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="vision-mission-card h-100 p-5 bg-white rounded shadow-sm position-relative overflow-hidden">
                        <div class="position-absolute top-0 end-0 mt-3 me-4">
                            <i class="fas fa-bullseye fa-3x text-primary opacity-10"></i>
                        </div>
                        <div class="d-flex align-items-center mb-4">
                            <div class="icon-box me-4">
                                <i class="fas fa-bullseye fa-2x text-primary"></i>
                            </div>
                            <h3 class="mb-0">Our Vision</h3>
                        </div>
                        <p class="mb-4 fs-5 fw-medium text-dark">To be a trusted global leader in high-quality components and energy solutions, delivering scalable, cost-effective, and reliable services.</p>
                        <div class="d-flex align-items-center text-primary">
                            <span class="me-2">Our guiding star</span>
                            <i class="fas fa-arrow-right"></i>
                        </div>
                    </div>
                </div>

                <!-- Mission Cards -->
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="row g-4 h-100">
                        <!-- Mission 1 -->
                        <div class="col-md-6">
                            <div class="vision-mission-card h-100 p-4 bg-white rounded shadow-sm">
                                <div class="icon-box-sm mb-3">
                                    <i class="fas fa-award text-primary"></i>
                                </div>
                                <h5 class="mb-3">Quality Components</h5>
                                <p class="mb-0">To provide high-quality components and products with efficiency and reliability</p>
                            </div>
                        </div>

                        <!-- Mission 2 -->
                        <div class="col-md-6">
                            <div class="vision-mission-card h-100 p-4 bg-white rounded shadow-sm">
                                <div class="icon-box-sm mb-3">
                                    <i class="fas fa-chart-line text-primary"></i>
                                </div>
                                <h5 class="mb-3">Scalable Solutions</h5>
                                <p class="mb-0">To support clients with scalable, flexible, and cost-effective trading solutions</p>
                            </div>
                        </div>

                        <!-- Mission 3 -->
                        <div class="col-md-6">
                            <div class="vision-mission-card h-100 p-4 bg-white rounded shadow-sm">
                                <div class="icon-box-sm mb-3">
                                    <i class="fas fa-handshake text-primary"></i>
                                </div>
                                <h5 class="mb-3">Trusted Relationships</h5>
                                <p class="mb-0">To build long-term relationships based on trust, integrity, and performance</p>
                            </div>
                        </div>

                        <!-- Mission 4 -->
                        <div class="col-md-6">
                            <div class="vision-mission-card h-100 p-4 bg-white rounded shadow-sm">
                                <div class="icon-box-sm mb-3">
                                    <i class="fas fa-leaf text-primary"></i>
                                </div>
                                <h5 class="mb-3">Global Sustainability</h5>
                                <p class="mb-0">To contribute to global sustainability through advanced energy solutions</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mission & Vision End -->

    <!-- Solutions Spotlight End -->
    <!-- Booking End -->

    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>




</body>

</html>