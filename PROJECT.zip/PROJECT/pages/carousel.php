<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title> Your Trusted Global Partner in Electronics & Industrial Trade</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../lib/animate/animate.min.css" rel="stylesheet">
    <!-- Change paths to work from both locations -->
    <link href="<?= HTTP_SERVER ?>lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?= HTTP_SERVER ?>lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- And so on -->
    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
</head>

<body>


    <div class="container-fluid p-0 mb-5">
        <div class="owl-carousel header-carousel position-relative">
            <!-- Slide 1 -->
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="img/tech.jpg" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(0, 0, 0, .4);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-10 col-lg-8">
                                <h5 class="text-white text-uppercase mb-3 animated slideInDown">Electronic & Industrial Solutions</h5>
                                <h1 class="display-3 text-white animated slideInDown mb-4">Powering Global Industries</h1>
                                <p class="fs-5 fw-medium text-white mb-4 pb-2">Encore Global Co., Limited delivers reliable electronic components, cutting-edge automotive systems, and scalable industrial technologies since 2022.</p>
                                <a href="<?= HTTP_SERVER ?>pages/about-section.php" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                                <a href="<?= HTTP_SERVER ?>pages/contact.php" class="btn btn-secondary py-md-3 px-md-5 animated slideInRight">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Slide 2 -->
            <!-- Slide 2 -->
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="img/renewable.jpg" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(0, 0, 0, .4);">
                    <div class="container">
                        <div class="row justify-content-start">
                            <div class="col-10 col-lg-8">
                                <h5 class="text-white text-uppercase mb-3 animated slideInDown">Sustainable Power for Tomorrow </h5>
                                <h1 class="display-3 text-white animated slideInDown mb-4"> Renewable Energy Solutions</h1>
                                <p class="fs-5 fw-medium text-white mb-4 pb-2">Empowering industries with smart renewable energy technologies that drive efficiency and reduce environmental impact.</p>
                                <a href="<?= HTTP_SERVER ?>pages/service-section.php" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Discover</a>
                                <a href="<?= HTTP_SERVER ?>pages/contact.php" class="btn btn-secondary py-md-3 px-md-5 animated slideInRight">Get in Touch</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-0 back-to-top"><i class="bi bi-arrow-up"></i></a>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/wow/wow.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/counterup/counterup.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../lib/tempusdominus/js/moment.min.js"></script>
    <script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>


    <script src="../js/main.js"></script>
</body>

</html>